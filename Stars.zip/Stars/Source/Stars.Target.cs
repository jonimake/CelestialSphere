// Copyright Joni Käki-Mäkelä

using UnrealBuildTool;
using System.Collections.Generic;

public class StarsTarget : TargetRules
{
	public StarsTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		DefaultBuildSettings = BuildSettingsVersion.V2;

		ExtraModuleNames.AddRange( new string[] { "Stars" } );
	}
}
