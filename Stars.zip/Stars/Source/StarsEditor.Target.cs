// Copyright Joni Käki-Mäkelä

using UnrealBuildTool;
using System.Collections.Generic;

public class StarsEditorTarget : TargetRules
{
	public StarsEditorTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Editor;
		DefaultBuildSettings = BuildSettingsVersion.V2;

		ExtraModuleNames.AddRange( new string[] { "Stars" } );
	}
}
