// Copyright Joni Käki-Mäkelä

#include "Stars.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Stars, "Stars" );
